package ml.dstudios.travmeet;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class SplashActivity extends AppCompatActivity {

    TextView captionText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        captionText = findViewById(R.id.caption_text);
        captionText.animate().alpha(1f).scaleX(1.10f).scaleY(1.10f).setDuration(1500);

        Handler handler = new Handler();

        if (FirebaseAuth.getInstance().getCurrentUser()==null){
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(intent);
                }
            }, 1700);
        }

        else{
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                }
            }, 1700);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}